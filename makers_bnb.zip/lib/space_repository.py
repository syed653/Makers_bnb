from lib.space import Space

class SpaceRepository:
    def __init__( self, connection):
        self._connection = connection

    def all(self):
        rows = self._connection.execute('SELECT * FROM spaces')
        spaces = []
        for row in rows:
            space = Space(row["id"], row["name"], row["description"], row["price"], row["user_id"])
            spaces.append(space)
        return spaces

    def create(self, space):
        self._connection.execute(
            'INSERT INTO spaces (name, description, price, user_id) VALUES (%s, %s, %s, %s)',
            [space.name, space.description, space.price, space.user_id]
        )
        return None

    def find(self, space_id):
        rows = self._connection.execute(
            'SELECT * FROM spaces WHERE id = %s', [space_id]
    )
        row = rows[0]
        return Space(row["id"], row["name"], row["description"], row["price"], row["user_id"])